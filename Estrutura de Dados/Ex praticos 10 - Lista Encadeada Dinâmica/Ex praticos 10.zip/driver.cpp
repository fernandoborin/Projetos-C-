#include "List.h"
#include <iostream>
using namespace std;

int main(){
    List Lista1;

    Lista1.Insert(1, 15);
    Lista1.Insert(2, 6);
    Lista1.Insert(3, 7);
    Lista1.Insert(4, 21);
    Lista1.Insert(5, 18);
}