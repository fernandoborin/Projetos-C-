#include <iostream>
#include "esfera.h"

int main(){
    esfera R1, R2;

    R1.atribuiRaio(10);
    R2.atribuiRaio(20);
}