#include <iostream>
#include "esfera.h"

double esfera::calcularRaio(){

    return raio;
}

void esfera::atribuiRaio(double r){
    raio = r;

}