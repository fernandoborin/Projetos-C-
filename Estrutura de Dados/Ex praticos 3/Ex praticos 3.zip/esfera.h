class esfera{
    public:
    double calcularRaio();
    void atribuiRaio(double r);

    private:
    double raio;
};